document.addEventListener("DOMContentLoaded", () => {
    const formProyecto = document.getElementById("form-proyecto");
    const listaProyectos = document.getElementById("lista-proyectos");

    let proyectos = [];
    let editIndex = -1;

    formProyecto.addEventListener("submit", (event) => {
        event.preventDefault();

        const nombreClave = document.getElementById("nombre-clave").value;
        const titulo = document.getElementById("titulo").value;
        const descripcion = document.getElementById("descripcion").value;
        const fechaInicio = document.getElementById("fecha-inicio").value;
        const fechaFinEstimada = document.getElementById("fecha-fin-estimada").value;

        const proyecto = {
            nombreClave,
            titulo,
            descripcion,
            fechaInicio,
            fechaFinEstimada,
            tareas: [],
            completed: false // Nuevo campo para marcar el proyecto como completado
        };

        if (editIndex === -1) {
            proyectos.push(proyecto);
        } else {
            proyectos[editIndex] = proyecto;
            editIndex = -1;
        }

        renderProyectos();
        formProyecto.reset();
    });

    function renderProyectos() {
        listaProyectos.innerHTML = "";
        proyectos.forEach((proyecto, index) => {
            const tareasHtml = proyecto.tareas.map((tarea, taskIndex) => {
                const subtareasHtml = tarea.subtasks.map((subtask, subIndex) => `
                    <div class="subtarea">
                        <input type="checkbox" id="subtask-${index}-${taskIndex}-${subIndex}" ${subtask.completed ? 'checked' : ''} onclick="updateSubtask(${index}, ${taskIndex}, ${subIndex})">
                        <label for="subtask-${index}-${taskIndex}-${subIndex}">${subtask.name}</label>
                    </div>
                `).join('');

                return `
                    <div class="tarea">
                        <input type="checkbox" id="task-${index}-${taskIndex}" ${tarea.completed ? 'checked' : ''} onclick="updateTask(${index}, ${taskIndex})">
                        <label for="task-${index}-${taskIndex}" class="task-title">${tarea.taskName}</label>
                        <div class="task-details">
                            <p>Descripción: ${tarea.taskDesc}</p>
                            <p>Fecha de Inicio: ${tarea.taskStartDate}</p>
                            <p>Fecha de Finalización: ${tarea.taskEndDate}</p>
                        </div>
                        <div class="checkbox-group">
                            ${subtareasHtml}
                        </div>
                        <button onclick="editarTarea(${index}, ${taskIndex})">Editar Tarea</button>
                        <button onclick="eliminarTarea(${index}, ${taskIndex})">Eliminar Tarea</button>
                    </div>
                `;
            }).join('');

            const progress = calculateProjectProgress(proyecto.tareas, proyecto.completed);
            const proyectoDiv = document.createElement("div");
            proyectoDiv.classList.add("proyecto");
            proyectoDiv.innerHTML = `
                <h3>${proyecto.titulo} (${proyecto.nombreClave})</h3>
                <p>${proyecto.descripcion}</p>
                <p>Inicio: ${proyecto.fechaInicio}</p>
                <p>Fin Estimada: ${proyecto.fechaFinEstimada}</p>
                ${proyecto.tareas.length === 0 ? `<input type="checkbox" id="project-${index}" ${proyecto.completed ? 'checked' : ''} onclick="updateProject(${index})"> <label for="project-${index}">Completar Proyecto</label>` : ''}
                <div class="progress-bar"><span style="width: ${progress}%">${progress}%</span></div>
                ${tareasHtml}
                <button onclick="editarProyecto(${index})">Editar Proyecto</button>
                <button onclick="eliminarProyecto(${index})">Eliminar Proyecto</button>
                <button onclick="showAddTaskForm(${index})">Agregar Tarea</button>
            `;
            listaProyectos.appendChild(proyectoDiv);
        });
    }

    function calculateSubtaskProgress(subtasks) {
        const total = subtasks.length;
        if (total === 0) return 0;
        const completed = subtasks.filter(subtask => subtask.completed).length;
        return (completed / total) * 100;
    }

    function calculateTaskProgress(tarea) {
        if (tarea.subtasks.length === 0) {
            return tarea.completed ? 100 : 0;
        }
        return calculateSubtaskProgress(tarea.subtasks);
    }

    function calculateProjectProgress(tareas, completed) {
        if (completed) return 100; // Si el proyecto está marcado como completado, devolver 100%
        const totalTasks = tareas.length;
        if (totalTasks === 0) return 0;
        const totalProgress = tareas.reduce((acc, tarea) => acc + calculateTaskProgress(tarea), 0);
        return totalProgress / totalTasks;
    }

    window.updateProject = (projectIndex) => {
        const isChecked = document.getElementById(`project-${projectIndex}`).checked;
        proyectos[projectIndex].completed = isChecked;
        renderProyectos();
    };

    window.updateTask = (projectIndex, taskIndex) => {
        const isChecked = document.getElementById(`task-${projectIndex}-${taskIndex}`).checked;
        proyectos[projectIndex].tareas[taskIndex].completed = isChecked;
        renderProyectos();
    };

    window.updateSubtask = (projectIndex, taskIndex, subtaskIndex) => {
        const isChecked = document.getElementById(`subtask-${projectIndex}-${taskIndex}-${subtaskIndex}`).checked;
        proyectos[projectIndex].tareas[taskIndex].subtasks[subtaskIndex].completed = isChecked;
        renderProyectos();
    };

    window.showAddTaskForm = (projectIndex) => {
        const taskName = prompt("Ingrese el nombre de la tarea:");
        if (taskName) {
            const taskDesc = prompt("Ingrese la descripción de la tarea:");
            const taskStartDate = prompt("Ingrese la fecha de inicio de la tarea (YYYY-MM-DD):");
            const taskEndDate = prompt("Ingrese la fecha de finalización de la tarea (YYYY-MM-DD):");

            const subtasks = [];

            const tarea = {
                taskName,
                taskDesc,
                taskStartDate,
                taskEndDate,
                subtasks,
                completed: false // Nueva tarea comienza como no completada
            };

            proyectos[projectIndex].tareas.push(tarea);
            renderProyectos();
        }
    };

    window.editarTarea = (projectIndex, taskIndex) => {
        const tarea = proyectos[projectIndex].tareas[taskIndex];
        const newTaskName = prompt("Ingrese el nuevo nombre de la tarea:", tarea.taskName);
        if (newTaskName !== null) {
            tarea.taskName = newTaskName;
            tarea.taskDesc = prompt("Ingrese la nueva descripción de la tarea:", tarea.taskDesc);
            tarea.taskStartDate = prompt("Ingrese la nueva fecha de inicio de la tarea (YYYY-MM-DD):", tarea.taskStartDate);
            tarea.taskEndDate = prompt("Ingrese la nueva fecha de finalización de la tarea (YYYY-MM-DD):", tarea.taskEndDate);
            renderProyectos();
        }
    };

    window.eliminarTarea = (projectIndex, taskIndex) => {
        proyectos[projectIndex].tareas.splice(taskIndex, 1);
        renderProyectos();
    };

    window.editarProyecto = (index) => {
        const proyecto = proyectos[index];
        document.getElementById("nombre-clave").value = proyecto.nombreClave;
        document.getElementById("titulo").value = proyecto.titulo;
        document.getElementById("descripcion").value = proyecto.descripcion;
        document.getElementById("fecha-inicio").value = proyecto.fechaInicio;
        document.getElementById("fecha-fin-estimada").value = proyecto.fechaFinEstimada;
        editIndex = index;
    };

    window.eliminarProyecto = (index) => {
        proyectos.splice(index, 1);
        renderProyectos();
    };

    function init() {
        renderProyectos();
    }

    init();
});
